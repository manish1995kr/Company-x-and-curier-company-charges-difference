#!/usr/bin/env python
# coding: utf-8

# In[1]:


# First import pandas for the read the excel file.
# In this all code I use the Pandas and numpy Library.

import pandas as pd


# In[7]:


# In this read the courier company rates file in python and save in the courier_company_rate dataframe.

courier_company_rate = pd.read_excel("Courier Company - Rates.xlsx",sheet_name = "Sheet1",engine = "openpyxl")
courier_company_rate


# In[145]:


# In this read the courier company invoice file in python and save in the courier_company_invoice dataframe.

courier_company_invoice = pd.read_excel("Courier Company - Invoice.xlsx",sheet_name = "Sheet1",engine = "openpyxl")
courier_company_invoice


# In[73]:


# In this read the company x SKU Master file in python and save in the company_x_sku dataframe.

company_x_sku = pd.read_excel("Company X - SKU Master.xlsx",sheet_name = "Sheet1",engine = "openpyxl")
company_x_sku


# In[142]:


# In this read the company x pincode zones file in python and save in the company_x_pincode dataframe.

company_x_pincode = pd.read_excel("Company X - Pincode Zones.xlsx",sheet_name = "Sheet1",engine = "openpyxl")
company_x_pincode


# In[135]:


#By this code we read the company x order report excel file and give the name company_x_order.

company_x_order = pd.read_excel("Company X - Order Report.xlsx",sheet_name = "Sheet1",engine = "openpyxl")
company_x_order


# In[136]:


# In this i change the column name of company x order file.
# then i use the head function to see only 2 rows of the dataframe.

company_x_order.rename(columns = {'ExternOrderNo':'Order ID'},inplace = True)
company_x_order.head(2)


# In[137]:


# Now i merge the company x sku file and company x oreder file with the column SKU.

final_x = pd.merge(company_x_sku,company_x_order, how = "right", on = "SKU")
final_x


# In[138]:


# In this first group the order ID and behave of group add the weight and order qty column,
# and then reset the index, and save it with the name of final_x.

final_x = final_x.groupby("Order ID")["Weight (g)","Order Qty"].sum()
final_x.reset_index(inplace = True)
final_x


# In[140]:


# Now to calculate the total weight in kg first i multiply the order qty with weight(g) and then divide it by 1000
#and save the output result in new column total weight x (kg).

final_x["total_weight_x_(kg)"] = final_x["Order Qty"]*(final_x["Weight (g)"]/1000)
final_x


# In[141]:


#now to calculate the weight slap i give the condition in condition_x_company variable and the result of condition
#in varible_x_company and then use the numpy.select function so the result will save in new column weight_slap_x in final_x
# to use the numpy first import the numpy.

import numpy as np
condition_x_company = [(final_x["total_weight_x_(kg)"]<=0.5),
(final_x["total_weight_x_(kg)"]>0.5) & (final_x["total_weight_x_(kg)"]<=1),
(final_x["total_weight_x_(kg)"]>1) & (final_x["total_weight_x_(kg)"]<=1.5),
(final_x["total_weight_x_(kg)"]>1.5) & (final_x["total_weight_x_(kg)"]<=2),
(final_x["total_weight_x_(kg)"]>2) & (final_x["total_weight_x_(kg)"]<=2.5),
(final_x["total_weight_x_(kg)"]>2.5) & (final_x["total_weight_x_(kg)"]<=3),
(final_x["total_weight_x_(kg)"]>3) & (final_x["total_weight_x_(kg)"]<=3.5),
(final_x["total_weight_x_(kg)"]>3.5) & (final_x["total_weight_x_(kg)"]<=4),
(final_x["total_weight_x_(kg)"]>4) & (final_x["total_weight_x_(kg)"]<=4.5),
(final_x["total_weight_x_(kg)"]>4.5) & (final_x["total_weight_x_(kg)"]<=5),
(final_x["total_weight_x_(kg)"]>5) & (final_x["total_weight_x_(kg)"]<=5.5),
(final_x["total_weight_x_(kg)"]>5.5) & (final_x["total_weight_x_(kg)"]<=6),
(final_x["total_weight_x_(kg)"]>6) & (final_x["total_weight_x_(kg)"]<=6.5),
(final_x["total_weight_x_(kg)"]>6.5) & (final_x["total_weight_x_(kg)"]<=7),
(final_x["total_weight_x_(kg)"]>7) & (final_x["total_weight_x_(kg)"]<=7.5),
(final_x["total_weight_x_(kg)"]>7.5) & (final_x["total_weight_x_(kg)"]<=8),
(final_x["total_weight_x_(kg)"]>8) & (final_x["total_weight_x_(kg)"]<=8.5),
(final_x["total_weight_x_(kg)"]>8.5) & (final_x["total_weight_x_(kg)"]<=9),
(final_x["total_weight_x_(kg)"]>9) & (final_x["total_weight_x_(kg)"]<=9.5),
(final_x["total_weight_x_(kg)"]>9.5) & (final_x["total_weight_x_(kg)"]<=10),
(final_x["total_weight_x_(kg)"]>10) & (final_x["total_weight_x_(kg)"]<=10.5),
(final_x["total_weight_x_(kg)"]>10.5) & (final_x["total_weight_x_(kg)"]<=11),
(final_x["total_weight_x_(kg)"]>11) & (final_x["total_weight_x_(kg)"]<=11.5),
(final_x["total_weight_x_(kg)"]>11.5) & (final_x["total_weight_x_(kg)"]<=12),
(final_x["total_weight_x_(kg)"]>12) & (final_x["total_weight_x_(kg)"]<=12.5),
(final_x["total_weight_x_(kg)"]>12.5) & (final_x["total_weight_x_(kg)"]<=13),
(final_x["total_weight_x_(kg)"]>13) & (final_x["total_weight_x_(kg)"]<=13.5),
(final_x["total_weight_x_(kg)"]>13.5) & (final_x["total_weight_x_(kg)"]<=14),
(final_x["total_weight_x_(kg)"]>14) & (final_x["total_weight_x_(kg)"]<=14.5),
(final_x["total_weight_x_(kg)"]>14.5) & (final_x["total_weight_x_(kg)"]<=15),
(final_x["total_weight_x_(kg)"]>15) & (final_x["total_weight_x_(kg)"]<=15.5),
(final_x["total_weight_x_(kg)"]>15.5) & (final_x["total_weight_x_(kg)"]<=16),
(final_x["total_weight_x_(kg)"]>16) & (final_x["total_weight_x_(kg)"]<=16.5),
(final_x["total_weight_x_(kg)"]>16.5) & (final_x["total_weight_x_(kg)"]<=17),
(final_x["total_weight_x_(kg)"]>17) & (final_x["total_weight_x_(kg)"]<=17.5),
(final_x["total_weight_x_(kg)"]>17.5) & (final_x["total_weight_x_(kg)"]<=18),
(final_x["total_weight_x_(kg)"]>18) & (final_x["total_weight_x_(kg)"]<=18.5),
(final_x["total_weight_x_(kg)"]>18.5) & (final_x["total_weight_x_(kg)"]<=19),
(final_x["total_weight_x_(kg)"]>19) & (final_x["total_weight_x_(kg)"]<=19.5),
(final_x["total_weight_x_(kg)"]>19.5) & (final_x["total_weight_x_(kg)"]<=20),
(final_x["total_weight_x_(kg)"]>20) & (final_x["total_weight_x_(kg)"]<=20.5),]

values_x_company = [0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8,8.5,9,9.5,10,10.5,11,11.5,12,12.5,13,13.5,14,14.5
                   ,15,15.5,16,16.5,17,17.5,18,18.5,19,19.5,20,20.5]

final_x["weight_slap_x"] = np.select(condition_x_company,values_x_company)
final_x


# In[143]:


# In this we rename the zone column name. and use the head function to check column name change or not.

company_x_pincode.rename(columns = {'Zone':'zone_by_x'},inplace = True)
company_x_pincode.head(2)


# In[146]:


# now to calculate the weight slap i give the condition in condition variable and the result of condition
# in values and then use the numpy.select function so the result will save in new column weight_slap_courier in 
# courier_company_invoice to use the numpy first import the numpy.

condition = [(courier_company_invoice["Charged Weight"]<=0.5),
(courier_company_invoice["Charged Weight"]>0.5) & (courier_company_invoice["Charged Weight"]<=1),
(courier_company_invoice["Charged Weight"]>1) & (courier_company_invoice["Charged Weight"]<=1.5),
(courier_company_invoice["Charged Weight"]>1.5) & (courier_company_invoice["Charged Weight"]<=2),
(courier_company_invoice["Charged Weight"]>2) & (courier_company_invoice["Charged Weight"]<=2.5),
(courier_company_invoice["Charged Weight"]>2.5) & (courier_company_invoice["Charged Weight"]<=3),
(courier_company_invoice["Charged Weight"]>3) & (courier_company_invoice["Charged Weight"]<=3.5),
(courier_company_invoice["Charged Weight"]>3.5) & (courier_company_invoice["Charged Weight"]<=4),
(courier_company_invoice["Charged Weight"]>4) & (courier_company_invoice["Charged Weight"]<=4.5),
(courier_company_invoice["Charged Weight"]>4.5) & (courier_company_invoice["Charged Weight"]<=5)]

values = [0.5,1,1.5,2,2.5,3,3.5,4,4.5,5]

courier_company_invoice["weight_slap_courier"] = np.select(condition,values)


# In[147]:


# to see the weight slap courier column added or not we use the head function to see the first 5 row of the table.

courier_company_invoice.head()


# In[158]:


# In this code i merge the two file courier_company_invoice and final_x  by the common column Order ID with the help of
# panda merge function.

company_x_merge = pd.merge(courier_company_invoice,final_x, how = "right", on = "Order ID")
company_x_merge


# In[164]:


# In this code i rename the column and check the column name changed with the help of head function.

company_x_merge.rename(columns = {'Zone':'zone_by_courier'
                                 ,'Charged Weight':'charged_weight_by_courier','Billing Amount (Rs.)':
                                  'charged_amount_by_courier'},inplace = True)
company_x_merge.head(2)


# In[167]:


# Now we again merge the two file company_x_pincode and company_x_merge with the common column customer pincode.

company_x_merge = pd.merge(company_x_pincode,company_x_merge, how = "right", on = "Customer Pincode")
company_x_merge


# In[171]:


# To calculate the expected charged by x company we use this code condition given in con and the result come of by 
# this condition the output result given in val and then give to the numpy select function.

a_fixed = 29.5
a_additional = 23.6
b_fixed = 33
b_additional = 28.3
c_fixed = 40.1
c_additional = 38.9
d_fixed = 44.8
d_additional = 56.6
e_fixed = 55.5
e_additional = 55.5

rto_a_fixed = 13.6
rto_a_additional = 23.6
rto_b_fixed = 20.5
rto_b_additional = 28.3
rto_c_fixed = 31.9
rto_c_additional = 38.9
rto_d_fixed = 41.3
rto_d_additional = 44.8
rto_e_fixed = 50.7
rto_e_additional = 55.5

con = [(company_x_merge["zone_by_x"] == "a") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "a") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
      
      (company_x_merge["zone_by_x"] == "b") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "b") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
      
      (company_x_merge["zone_by_x"] == "c") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "c") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
      
      (company_x_merge["zone_by_x"] == "d") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "d") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
      
      (company_x_merge["zone_by_x"] == "e") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "e") & (company_x_merge["Type of Shipment"] == "Forward charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
       
      (company_x_merge["zone_by_x"] == "a") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "a") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
       
      (company_x_merge["zone_by_x"] == "b") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "b") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
       
      (company_x_merge["zone_by_x"] == "c") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "c") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
       
      (company_x_merge["zone_by_x"] == "d") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "d") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
      
      (company_x_merge["zone_by_x"] == "e") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]==0.5),
      (company_x_merge["zone_by_x"] == "e") & (company_x_merge["Type of Shipment"] == "Forward and RTO charges") & 
      (company_x_merge["weight_slap_x"]!=0.5),
      ]

val = [a_fixed,(a_fixed+(company_x_merge["weight_slap_x"]/0.5)*a_additional),
       b_fixed,(b_fixed+(company_x_merge["weight_slap_x"]/0.5)*b_additional),
      c_fixed,(c_fixed+(company_x_merge["weight_slap_x"]/0.5)*c_additional),
      d_fixed,(d_fixed+(company_x_merge["weight_slap_x"]/0.5)*d_additional),
      e_fixed,(e_fixed+(company_x_merge["weight_slap_x"]/0.5)*e_additional),
      (a_fixed+rto_a_fixed),(a_fixed+rto_a_fixed)+((company_x_merge["weight_slap_x"]/0.5)*a_additional)+
       ((company_x_merge["weight_slap_x"]/0.5)*rto_a_additional),
      (b_fixed+rto_b_fixed),(b_fixed+rto_b_fixed)+((company_x_merge["weight_slap_x"]/0.5)*b_additional)+
       ((company_x_merge["weight_slap_x"]/0.5)*rto_b_additional),
      (c_fixed+rto_c_fixed),(c_fixed+rto_c_fixed)+((company_x_merge["weight_slap_x"]/0.5)*c_additional)+
       ((company_x_merge["weight_slap_x"]/0.5)*rto_c_additional),
      (d_fixed+rto_d_fixed),(d_fixed+rto_d_fixed)+((company_x_merge["weight_slap_x"]/0.5)*d_additional)+
       ((company_x_merge["weight_slap_x"]/0.5)*rto_d_additional),
      (e_fixed+rto_e_fixed),(e_fixed+rto_e_fixed)+((company_x_merge["weight_slap_x"]/0.5)*e_additional)+
       ((company_x_merge["weight_slap_x"]/0.5)*rto_e_additional)]  

expected_charge_by_x = np.select(con,val)

expected_charge_by_x


# In[172]:


# Now the expected charged by x to save in the table and make the new column for this we use this code.

company_x_merge["expected_charge_by_x_company"] = expected_charge_by_x


# In[173]:


# Just to see the table how it look.

company_x_merge


# In[176]:


# Now to calculate the difference between charges of courier company and x company we use this code. In this we just minus
# the x company charge with the courier company charge and save in new column.

company_x_merge["difference_between_expected_charged_and_billed_charged(rs.)"] = company_x_merge["expected_charge_by_x_company"] - company_x_merge["charged_amount_by_courier"]


# In[191]:


# to check the column added in the table or not.

company_x_merge


# In[192]:


# In this we drop the column which we do not require in over table ny using the drop function.

final_report = company_x_merge.drop(["Warehouse Pincode_x","Customer Pincode","Warehouse Pincode_y","Type of Shipment","Weight (g)","Order Qty"],axis = 1)
final_report


# In[193]:


# Now to save the file in over system we use this code. The final_report.xlxs is the name which we give to save the file. 

final_report.to_excel("final_report.xlsx")


# In[190]:


# In this we see the correct charge, over charge, and under charge by the courier company.

correct = company_x_merge[company_x_merge["difference_between_expected_charged_and_billed_charged(rs.)"] == 0]

correct_charged_count = correct.charged_amount_by_courier.count()
correct_charged_sum = correct.charged_amount_by_courier.sum()
print("correct_charged_count :-",correct_charged_count)
print("correct_charged_sum :-",correct_charged_sum)

overcharged = company_x_merge[company_x_merge["difference_between_expected_charged_and_billed_charged(rs.)"] > 0]

over_charged_count = overcharged.charged_amount_by_courier.count()
over_charged_sum = overcharged.charged_amount_by_courier.sum()
print("over_charged_count :-",over_charged_count)
print("over_charged_sum :-",over_charged_sum)

undercharged = company_x_merge[company_x_merge["difference_between_expected_charged_and_billed_charged(rs.)"] < 0]

under_charged_count = undercharged.charged_amount_by_courier.count()
under_charged_sum = undercharged.charged_amount_by_courier.sum()
print("under_charged_count :-",under_charged_count)
print("under_charged_sum :-",under_charged_sum)


# In[ ]:




